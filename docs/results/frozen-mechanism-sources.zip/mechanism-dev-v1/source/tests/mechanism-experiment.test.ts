import assert from "node:assert/strict";
import test from "node:test";
import { mkdtemp, mkdir, readFile, writeFile, rm, copyFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";

const luna = "gpt-5.6-luna", astra = "gpt-6-astra";
const root = new URL("..", import.meta.url);
const sha = (data: string) => createHash("sha256").update(data).digest("hex");
function receipt(model = luna) {
  return { requestedModel: model, transcript: { requestedModel: model, effectiveModelEvidence: null,
    events: [{ type: "turn.completed", usage: { input_tokens: 25_000, cached_input_tokens: 0,
      cache_write_input_tokens: 0, output_tokens: 2000 } }] } };
}
async function priorRun(path: string, data: unknown = receipt()) {
  await mkdir(path, { recursive: true });
  const result = { success: true, calls: [{ id: "call-1", model: luna }], budget: { observedCredits: .185,
    unknownUsageCalls: 0, activeReservations: 0, exceeded: false }, boundaryViolations: [] };
  await writeFile(join(path, "result.json"), JSON.stringify(result));
  if (data !== null) await writeFile(join(path, "call-1.json"), JSON.stringify(data));
  return result;
}
function invoke(path: string, output: string, priors: string[] = []) {
  return spawnSync(process.execPath, [join(path, "scripts/mechanism-experiment.mjs"), "--mode", "pilot", "--output", output,
    ...priors.flatMap(prior => ["--prior", prior])], { encoding: "utf8", timeout: 15_000 });
}

// The isolated dispatcher runs a deterministic local receipt producer, never a model CLI.
async function fixture() {
  const path = await mkdtemp(join(tmpdir(), "sheep-mechanism-dispatch-"));
  for (const directory of ["src", "scripts", "tests", "pricing", "docs"]) await mkdir(join(path, directory));
  for (const file of ["scripts/mechanism-experiment.mjs", "src/credit-budget.ts", "src/cost-estimate.ts", "pricing/openai-2026-09-10.json"])
    await copyFile(new URL(file, root), join(path, file));
  for (const file of ["package-lock.json", "tsconfig.json"]) await writeFile(join(path, file), "{}");
  await writeFile(join(path, "package.json"), '{"type":"module"}');
  await writeFile(join(path, "docs/execplan-mechanism.md"), "Frozen test plan\n");
  await writeFile(join(path, "src/mechanism-cli.ts"), `
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
const args = process.argv.slice(2), value = key => args[args.indexOf(key) + 1];
const output = value("--output"), model = value("--method") === "single-astra" ? "gpt-6-astra" : "gpt-5.6-luna";
const experiment = JSON.parse(await readFile(join(dirname(output), "experiment.json"), "utf8"));
if (experiment.activeJob !== output.slice(output.lastIndexOf("/") + 1)) throw new Error("Missing pre-dispatch durable record");
await mkdir(output);
const receipt = { requestedModel: model, transcript: { requestedModel: model, effectiveModelEvidence: null,
 events: [{ type: "turn.completed", usage: {input_tokens: 25000, cached_input_tokens: 0, cache_write_input_tokens: 0, output_tokens: 2000} }] } };
const credit = model === "gpt-6-astra" ? 8.75 : .185;
const final = experiment.runs.length === experiment.planned.length - 1;
const overrun = process.env.SHEEP_TEST_FINAL_OVERRUN === "yes" && final;
if (process.env.SHEEP_TEST_MISSING_RECEIPT !== "yes") await writeFile(join(output, "call-1.json"), JSON.stringify(receipt));
await writeFile(join(output, "result.json"), JSON.stringify({ success: !overrun, calls:[{id:"call-1",model}],
 budget:{observedCredits:credit,unknownUsageCalls:0,activeReservations:0,exceeded:overrun},boundaryViolations:[] }));
`);
  return path;
}

test("dispatcher includes five development controls, retains prior costs, and freezes exact source bytes", async () => {
  const path = await fixture();
  try {
    const prior = join(path, "prior"), output = join(path, "out");
    await priorRun(prior);
    const child = invoke(path, output, [prior]);
    assert.equal(child.status, 0, child.stderr);
    const report = JSON.parse(await readFile(join(output, "experiment.json"), "utf8"));
    assert.equal(report.status, "completed");
    assert.equal(report.planned.length, 5);
    assert.equal(report.runs.length, 5);
    assert.equal(report.activeJob, null);
    assert.equal(report.observed.calls, 6);
    assert.ok(Math.abs(report.observed.credits - 9.675) < 1e-10);
    assert.deepEqual(report.observed.unknown, []);
    assert.equal(report.planned.filter((job: { method: string }) => job.method.startsWith("single-")).length, 2);
    const manifest = JSON.parse(await readFile(join(output, "source-manifest.json"), "utf8"));
    for (const file of manifest) {
      const contents = await readFile(join(output, "frozen-source", file.path), "utf8");
      assert.equal(sha(contents), file.sha256);
    }
    assert.notEqual(invoke(path, output, [prior]).status, 0);
    assert.deepEqual(JSON.parse(await readFile(join(output, "experiment.json"), "utf8")), report);
  } finally { await rm(path, { recursive: true, force: true }); }
});

test("prior missing receipts, identity conflicts, and unknown usage refuse all model dispatch", async () => {
  const path = await fixture();
  try {
    const samples = [null, { ...receipt(), requestedModel: astra },
      { transcript: { ...receipt().transcript, events: [...receipt().transcript.events, { type: "thread.started", model: astra }] } },
      { transcript: { requestedModel: luna, events: [] } }];
    for (let index = 0; index < samples.length; index++) {
      const prior = join(path, `prior-${index}`), output = join(path, `out-${index}`);
      await priorRun(prior, samples[index]);
      const child = invoke(path, output, [prior]);
      assert.notEqual(child.status, 0);
      assert.match(child.stderr, /Prior usage is unknown/);
      await assert.rejects(readFile(join(output, "experiment.json")), { code: "ENOENT" });
    }
  } finally { await rm(path, { recursive: true, force: true }); }
});

test("unfinished dispatched prior and changed declared result cannot become zero-cost continuation", async () => {
  const path = await fixture();
  try {
    const unfinished = join(path, "unfinished"); await mkdir(unfinished);
    await writeFile(join(unfinished, "experiment.json"), JSON.stringify({ status: "running", runs: [], activeJob: "staged-sheep-n4-r1" }));
    assert.match(invoke(path, join(path, "out-one"), [unfinished]).stderr, /Prior usage is unknown/);
    const changed = join(path, "changed"), result = await priorRun(join(changed, "run-1"));
    await writeFile(join(changed, "experiment.json"), JSON.stringify({ status: "completed", activeJob: null,
      runs: [{ id: "run-1", resultSha256: sha(JSON.stringify(result) + "changed") }] }));
    assert.match(invoke(path, join(path, "out-two"), [changed]).stderr, /Prior usage is unknown/);
  } finally { await rm(path, { recursive: true, force: true }); }
});

test("last-run overrun stops the study instead of being mislabeled completed", async () => {
  const path = await fixture();
  try {
    const output = join(path, "out");
    const child = spawnSync(process.execPath, [join(path, "scripts/mechanism-experiment.mjs"), "--output", output],
      { encoding: "utf8", timeout: 15_000, env: { ...process.env, SHEEP_TEST_FINAL_OVERRUN: "yes" } });
    assert.equal(child.status, 1, child.stderr);
    const report = JSON.parse(await readFile(join(output, "experiment.json"), "utf8"));
    assert.equal(report.runs.length, 5);
    assert.equal(report.status, "stopped");
    assert.equal(report.stopReason, "per-run-overrun");
    assert.equal(report.activeJob, null);
  } finally { await rm(path, { recursive: true, force: true }); }
});

test("missing current receipt stops immediately even when the child reports zero unknown calls", async () => {
  const path = await fixture();
  try {
    const output = join(path, "out");
    const child = spawnSync(process.execPath, [join(path, "scripts/mechanism-experiment.mjs"), "--output", output],
      { encoding: "utf8", timeout: 15_000, env: { ...process.env, SHEEP_TEST_MISSING_RECEIPT: "yes" } });
    assert.equal(child.status, 1, child.stderr);
    const report = JSON.parse(await readFile(join(output, "experiment.json"), "utf8"));
    assert.equal(report.runs.length, 1);
    assert.equal(report.status, "stopped");
    assert.equal(report.stopReason, "unknown-usage");
    assert.ok(report.observed.unknown.some((item: string) => item.includes("receipt is missing")));
  } finally { await rm(path, { recursive: true, force: true }); }
});
