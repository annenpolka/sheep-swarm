# 依存発見・継続記憶・選択的介入を実際のモデルで試す

This ExecPlan is a living document. Progress, Surprises & Discoveries, Decision Log, and Outcomes & Retrospective are updated during execution.

## Purpose / Big Picture

前回の短い静的変換では分からなかった、下位の人数、繰り返し仕事をした個体の記憶、必要時だけの上位介入の効果を、小さく検査可能な課題で測る。下位は `gpt-5.6-luna`、上位と強モデル単独対照は `gpt-6-astra` を明示して呼ぶ。公開単価からのクレジット相当、完成率、時間、介入、依存発見、実際の個体参加回数を同時に記録する。失敗も結果として保存し、創発や一般のリポジトリでの優位をこの試行だけで主張しない。

## Progress

- [x] (2026-09-09 23:16:29Z) 既存の課題研究・価格表・実装を確認し、28試行と小規模開発試行を設計。
- [x] (2026-09-09 23:16:29Z) 記憶なし条件で、私有履歴と履歴由来の割当をともに無効にする WorkerPool を実装・検査。
- [x] (2026-09-09 23:21:38Z) 3課題の基準解・境界変異検査と予算管理、実行器を追加。既存検査を含む204件・型・参照ハッシュが通過。
- [x] (2026-09-09 23:21:38Z) 単独モデルの増分確定・同量の4件履歴と、実際の呼出に基づく依存・参加数を確認。
- [ ] 小規模な実モデル試行で動作契約を確認。修正時は旧記録を保存。
- [ ] 本試行のソース・課題・設定を固定し28条件を実行。
- [ ] 実測、限界、再現手順を文書化し Draft PR を更新。

## Surprises & Discoveries

- Observation: 現在のカーネルは入力を閉じた後の再開を持たない。
  Evidence: `src/kernel.ts` の `closeInput()` は恒久的に入力を閉じる。そのため今回の段階変更は共通完了バリアでカーネルを新しくし、採用済み成果物と発見済み辺、個体プールを次段階へ渡す。版番号の権威は各段階内に限定される。
- Observation: 記憶上限0を単に `slice(-limit)` へ渡すと全履歴が残る。
  Evidence: `tests/worker-pool.test.ts` に記憶と近傍割当をともに無効にする回帰検査を追加した。
- Observation: 最初の開発試行はCLIのスキル説明短縮通知をツール実行と誤認して停止した。
  Evidence: `mechanism-dev-v1` のAstra単独1呼出、8.2735 credits相当を保存。イベントは `item.type=error` の診断であり、外部ツールの実行ではない。既知の診断種別を区別して再実行する。本試行には混ぜない。

## Decision Log

- Decision: 同じ48モジュールの仕事で N=8/16/32、C=8 を比較する。静的・意味依存・3段階更新の3課題を各2回で18試行、Luna/Astra単独を各課題1回で6試行、段階更新の記憶なし・上位なしをN16で各2回、合計28試行とする。
  Rationale: 人数と並列数を分離し、N32でも複数段階を通して履歴が蓄積する仕事量を与える。各条件2回は機構の予備評価であり統計的な優位性判定ではない。
  Date/Author: 2026-09-10 / Codex
- Decision: 1試行30 Standardクレジット相当、研究全体は開発試行込み最大1,200相当を実行開始の制限に使う。呼出予約はLuna 0.25、Astra 15とし、全役割と失敗・再試行を算入する。
  Rationale: 既存の公開価格スナップショットを固定して比較する。既に始まった呼出は予約超過し得るのでプロバイダのハード上限ではない。未知の使用量は無料として扱わず新規実行を止める。
  Date/Author: 2026-09-10 / Codex
- Decision: 下位は公開の成果物カタログから必要な内容を要求できる。実際に読んだ関係だけを依存として登録する。上位への相談機構は設けず、反復する意味的失敗を観測したときだけ上位が共有指針を変更する。
  Rationale: 真の依存グラフを実行器が先回りして渡すと依存発見を測れない。契約は常に旧指針より優先し、意図的な解けない矛盾を与えない。
  Date/Author: 2026-09-10 / Codex
- Decision: 外部リポジトリ、5段階、総記憶容量を揃えた対照、ランダム割当、時刻による進行中変更は次の評価に残す。
  Rationale: 今回は3種類の実行可能な課題で操作・予算・観測の妥当性を先に確かめる。研究案全体の実施完了とは扱わない。
  Date/Author: 2026-09-10 / Codex

## Outcomes & Retrospective

実測待ち。品質の失敗とプロトコルの不正、予算による未完了、使用量不明、観測境界違反を分けて報告する。

## Context and Orientation

以下のパスはリポジトリのルートを基準とする。`src/kernel.ts` が採用権限と読取版・証拠を検査し、`src/worker-pool.ts` が永続する個体の公平な割当と私有履歴を持つ。`src/codex-worker.ts` が独立した Codex CLI 呼出を行い、生の使用量とイベントを保存する。`src/cost-estimate.ts` と `pricing/openai-2026-09-10.json` はキャッシュを分けた公開単価換算を行う。Codex契約の実請求やプロバイダが実際に選んだモデルの証明とは異なる。

意味依存とは import 構文に現れず、公開レジストリから辿るポリシー等の契約依存を指す。段階更新では同じ個体群が3回の契約変更を続けて処理し、履歴を新しい契約より優先しない能力も測る。

## Plan of Work

`src/mechanism-fixture.ts` に3課題を生成する関数、公開部分検査、最終検査、基準解を実装する。基準解と最終検査はプロンプトへ渡さない。基準解成功・旧実装失敗・境界変異失敗を実モデル実行前に固定する。

`src/credit-budget.ts` に同期的な予約と生の使用量の精算を実装する。`src/mechanism-run.ts` は段階ごとのカーネルと共有する個体プールを使い、局所修正、追加読取、受動的な上位介入を記録する。`src/mechanism-cli.ts` と `scripts/mechanism-experiment.mjs` が一試行と固定行列を実行する。元の実行器と実測資料は保存する。

## Concrete Steps

作業ディレクトリは sheep-swarm のチェックアウト。まず `npm run check` と実行計画検査を実行する。小規模な各課題を実モデルで実行し、呼出・使用量・拒否・最終検査を確認する。確定したコマンドと本試行の設定は実装完了時にこの節へ追記する。

実行器の単独モデル経路も確認するため、開発試行は3課題のSheep N4に段階更新のLuna/Astra単独を加えた5条件、各1領域6モジュールとする。本試行28条件は変更しない。

```sh
npm run mechanism:experiment -- --mode pilot --output .sheep/mechanism-dev-v1
npm run mechanism:experiment -- --mode main --output .sheep/mechanism-study-v1 --prior .sheep/mechanism-dev-v1
```

出力は固定ソース、SHA-256 manifest、実行前の全条件、実行順のseed=20260910と結果を含む。追加の開発試行が必要なら別ディレクトリを使い、全ての過去ディレクトリを `--prior` で指定して費用を累積する。

開発試行v2は `--mode pilot --output .sheep/mechanism-dev-v2 --prior .sheep/mechanism-dev-v1`。開発時はLunaの静的→意味依存→段階更新、Luna単独→Astra単独の順で動作確認する。本試行の順序のみ事前にseedで混ぜる。

CLI は実行時も `--sandbox read-only --ignore-user-config --ephemeral` を維持する。CLI自身のローカル状態保存のため外側の実行許可を使用する。モデルがプロンプト外のツールを実行した場合は境界違反として試行を止める。この方式はOSによる最終検査の秘匿を保証しない。

## Validation and Acceptance

既存154検査、型検査、2つの参照ハッシュ検査を維持する。追加検査では、全課題の旧実装失敗・基準解成功・境界変異失敗、予算の同時予約、失敗の精算、未知使用量による停止、局所書込制限、追加依存発見、記憶なし、上位なし、最終判定の非漏洩を確認する。

実モデル呼出は要求モデル名・生の終端使用量・呼出ID・終了理由を保存し、最終判定とカーネル完了が一致することを確認する。28試行が失敗を含めて説明可能な記録を持てば予備実験として完了する。予算上限等で中断した場合は未実行条件を明示する。

## Idempotence and Recovery

出力は `.sheep/` 内の新規ディレクトリに保存し既存試行を上書きしない。途中終了は中断記録を残し、同じ試行を成功したことにしない。再実行は別IDとし追加費用を計上する。新実行器の途中再開は今回の範囲に含めない。既存の永続再開評価は独立した実装と結果として残す。

## Artifacts and Notes

生のCLI記録は `.sheep/` に保持して公開しない。公開成果物は設定、固定ソースのハッシュとアーカイブ、数値、検査結果、機密を含まない集計とする。`docs/results/mechanism-findings.md` に実測と解釈の限界をまとめる。

## Interfaces and Dependencies

Node.js、既存TypeScript環境、Codex CLIを使用し新しい実行依存は増やさない。`createMechanismFixture({family,groups,variant})` が成果物、変更段階、カタログ、可視・最終検査を返す。`CreditBudget.reserve(model,callId)` と `settle(callId,receipt)` は全モデル呼出を一意に予約・精算する。モデルの応答は `{writes:[{id,content}],readRequests:[id],note}` のJSONに固定する。下位は担当成果物だけ、上位は指針だけを書き換える。
