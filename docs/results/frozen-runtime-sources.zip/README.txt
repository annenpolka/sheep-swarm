Frozen MIT source snapshots; no transcripts or credentials.
scale-v1: M3 including the recovered-transport defect.
evaluation-v2: M4 durable restart and preliminary M5.
evaluation-v3: M5 main comparison, native import checks, incremental Single.
evaluation-v4: Manager observation dependency correction; other methods unchanged.
Source manifests contain exact per-file SHA256. Results describe CLI/model versions and limits.
